// functions/api/generate.js
// Cloudflare Pages Function — proxy ke Google Gemini API
// API key: GEMINI_API_KEY di Cloudflare Environment Variables
// FREE TIER: 1500 request/hari, 1juta token/menit — GRATIS!

export async function onRequestPost(context) {
  const { request, env } = context;

  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json",
  };

  try {
    const body = await request.json();
    if (!body.prompt) {
      return new Response(JSON.stringify({ error: "prompt required" }), { status: 400, headers: cors });
    }

    const key = env.GEMINI_API_KEY;
    if (!key) {
      return new Response(JSON.stringify({ error: "GEMINI_API_KEY belum di-set di Cloudflare" }), { status: 500, headers: cors });
    }

    // Gemini 2.0 Flash — model terbaru, cepat, gratis
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${key}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: body.prompt }] }],
          generationConfig: {
            temperature: 0.85,
            maxOutputTokens: 2048,
            responseMimeType: "application/json",
          },
        }),
      }
    );

    if (!res.ok) {
      const err = await res.text();
      return new Response(JSON.stringify({ error: "Gemini error", detail: err }), { status: res.status, headers: cors });
    }

    const data = await res.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || "[]";
    return new Response(JSON.stringify({ text }), { status: 200, headers: cors });

  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers: cors });
  }
}

export async function onRequestOptions() {
  return new Response(null, {
    status: 204,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}

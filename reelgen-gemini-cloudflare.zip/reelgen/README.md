# 🎬 ReelGen — Cloudflare Pages + Gemini AI (GRATIS!)

## Struktur
```
reelgen/
├── public/index.html          ← App utama
├── functions/api/generate.js  ← Proxy Gemini API
├── wrangler.toml
└── README.md
```

## 🎁 Gemini Free Tier
- 1.500 request/hari GRATIS
- Model: gemini-2.0-flash

## 🚀 Deploy

### 1. Dapatkan Gemini API Key (Gratis)
- Buka aistudio.google.com
- Login Google → Get API Key → Create API Key
- Copy: AIza...

### 2. Upload ke GitHub
- Buat repo: reelgen
- Upload semua file

### 3. Cloudflare Pages
- Workers & Pages → Create → Pages → Connect Git
- Build output: public
- Framework: None
- Build command: (kosong)

### 4. Set Environment Variable
- GEMINI_API_KEY = AIzaxxxxxxxxx

### 5. Redeploy → Done!
URL: https://reelgen.pages.dev
